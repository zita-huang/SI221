#ifndef _DOUBLESORT_
#define _DOUBLESORT_

/* doublesort(A,n): sorts array of n doubles */
void doublesort(double *A, int n);

#endif
