#include <string>
#include "Tree.h"
using namespace std;

//------ PART 1 ------------------------------------------
void insertInt(Tree<int> &T, int x){
    // integer x should be placed in the tree in the proper position
}


//------ PART 2 ------------------------------------------
int getMax(Tree<int> &T){
    // retrieves the maximum integer value stored in the tree
    return -1;
}

int getMin(Tree<int> &T){
    // retrieves the minimum integer value stored in the tree
    return -1;
}

//------ DON'T TOUCH BELOW HERE --------------------------

int main(){
  // set root
  Tree<int> T;

    int k;
    while(cin >> k){
        if(k <= 0 )
            break;

        if(T.size() == 0){
            T.createRoot(k);
        } else {
            insertInt(T, k);
        }
    }

  // Comment out for Part 2
  prettyPrint(T.getRoot());
  cout << "Size of tree: " << T.size() << endl;
    cout << "Max Value: " << getMax(T) << endl;
    cout << "Min Value: " << getMin(T) << endl;
    cout << "Max Depth: " << T.maxDepth(T.getRoot()) << endl;
  return 0;
}
